
from flask import Flask, render_template
import sqlite3
from datetime import datetime

app = Flask(__name__)
db_path = '/mnt/data/data.db'

def fetch_query(query, params=()):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    results = cursor.execute(query, params).fetchall()
    conn.close()
    return results

def format_datetime(timestamp):
    try:
        dt_object = datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
        return dt_object.strftime("%b %d, %I:%M %p")
    except (ValueError, TypeError):
        return str(timestamp)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/messages')
def messages():
    query = """
        SELECT 'SMS' as type, sms_type as sender, time, text
        FROM SMS
        UNION ALL
        SELECT 'Chat' as type, sender, time, text
        FROM ChatMessages
        ORDER BY time DESC
    """
    messages = fetch_query(query)
    for i in range(len(messages)):
        messages[i] = (*messages[i], format_datetime(messages[i][2]))
    return render_template('messages.html', messages=messages)

@app.route('/calls')
def calls():
    query = "SELECT call_type, from_to, time, duration, location FROM Calls ORDER BY time DESC"
    calls = fetch_query(query)
    for i in range(len(calls)):
        calls[i] = (*calls[i], format_datetime(calls[i][2]))
    return render_template('calls.html', calls=calls)

@app.route('/apps')
def apps():
    query = "SELECT application_name, package_name, install_date FROM InstalledApps"
    apps = fetch_query(query)
    for i in range(len(apps)):
        apps[i] = (*apps[i], format_datetime(apps[i][2]))
    return render_template('apps.html', apps=apps)

if __name__ == '__main__':
    app.run(debug=True)
