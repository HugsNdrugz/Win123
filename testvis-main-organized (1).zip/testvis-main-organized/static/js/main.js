// Initialize Feather icons
feather.replace();

// Base API URL
const apiUrl = window.location.origin;

// Utility: Fetch data from the API
async function fetchData(endpoint) {
    try {
        const response = await fetch(`${apiUrl}/${endpoint}`);
        if (!response.ok) throw new Error(`Failed to fetch ${endpoint}`);
        return await response.json();
    } catch (error) {
        console.error(error);
        return [];
    }
}

// Populate Contacts
async function populateContacts() {
    const contacts = await fetchData('contacts');
    const listElement = document.querySelector('#chats .chat-list');
    listElement.innerHTML = '';
    contacts.forEach(contact => {
        const contactItem = document.createElement('div');
        const lastMessage = contact.lastMessage || { text: "", time: "" };
        contactItem.className = 'chat-item';
        contactItem.innerHTML = `
            <img src="${contact.avatar || 'https://via.placeholder.com/50'}" alt="${contact.name}'s Avatar">
            <div class="chat-details">
                <span class="name">${contact.name}</span>
                <span class="preview">${lastMessage.text}</span>
                
            </div>
            <span class="time">${lastMessage.time}</span>
            ${contact.unread ? '<div class="unread-indicator"></div>' : ''}
        `;
        contactItem.addEventListener('click', () => showMessages(contact.name));
        listElement.appendChild(contactItem);
    });
}

// Show Messages (SMS)
async function showMessages(contactName) {
    const messages = await fetchData(`sms/${contactName}`);
    const chatWindow = document.querySelector('.chat-window');
    
    // Create chat header
    const header = document.createElement('div');
    header.className = 'chat-header';
    header.innerHTML = `
        <button class="btn btn-link" onclick="closeChatWindow()">
            <i data-feather="arrow-left"></i>
        </button>
        <img src="https://via.placeholder.com/50" alt="${contactName}'s Avatar" class="avatar">
        <div class="user-info">
            <h4 class="mb-0 ms-3">${contactName}</h4>
            <p class="mb-0 ms-3">Active...</p>
        </div>
        <div class="chat-actions">
            <i data-feather="phone"></i>
            <i data-feather="video"></i>
            <i data-feather="more-horizontal"></i>
        </div>
        
    `;
    
    // Create messages container
    const messagesContainer = document.createElement('div');
    messagesContainer.className = 'messages-container';
    
    messages.forEach(msg => {
        const messageElement = document.createElement('div');
        messageElement.className = `message-item ${msg.sender === 'user' ? 'user-message' : 'contact-message'}`;
        messageElement.innerHTML = `
            <div class="message-content">
                ${msg.sender !== 'user' ? `<img src="https://via.placeholder.com/50" alt="${contactName}'s Avatar" class="avatar-message">` : ''}
                <p class="message-text">${msg.text}</p>
                
            </div>
            <span class="message-time">${msg.time}</span>
            
        `;
        messagesContainer.appendChild(messageElement);
    });
    
    chatWindow.innerHTML = '';
    chatWindow.appendChild(header);
    chatWindow.appendChild(messagesContainer);
    chatWindow.style.display = 'flex';
    
    // Re-initialize Feather icons for new elements
    feather.replace();
}

// Show Call History
async function showCallHistory() {
    const calls = await fetchData('calls');
    const listElement = document.querySelector('#archived .archived-list');
    listElement.innerHTML = '';
    calls.forEach(call => {
        const callItem = document.createElement('div');
        callItem.className = 'call-item';
        callItem.innerHTML = `
            <img src="${call.avatar || 'https://via.placeholder.com/50'}" alt="Avatar">
            <div class="call-details">
                <span class="name">${call.name}</span>
                <span class="time">You are now connected on Messenger ${call.time}</span>
            </div>
        `;
        listElement.appendChild(callItem);
    });
    feather.replace();
}

// Populate Settings
async function populateSettings() {
    const settings = await fetchData('settings');
    const settingsContainer = document.getElementById('settings-content');
    settingsContainer.innerHTML = `
        <div class="account-info">
            <img src="${settings.account.avatar || 'https://via.placeholder.com/100'}" alt="Profile Picture" class="profile-picture">
            <div class="user-details">
                <h3>${settings.account.name}</h3>
                <p class="profile-link">See your profile</p>
            </div>
        </div>
        <div class="setting-option">
            <i data-feather="toggle-left" class="setting-icon"></i>
            <div class="setting-text">
                <h4>Active Status: ON</h4>
            </div>
        </div>
        <div class="notifications">
            <h2>Notifications</h2>
            <div class="setting-option">
                <i data-feather="volume-2" class="setting-icon"></i>
                <div class="setting-text">
                    <h4>Notification sounds</h4>
                    <p>Use sounds to notify you about incoming messages, calls, video chats, and in-app sounds.</p>
                </div>
                <input class="form-check-input" type="checkbox" id="notificationSounds" ${settings.notifications.notificationSounds ? 'checked' : ''}>
            </div>
            <div class="setting-option">
                <i data-feather="volume-x" class="setting-icon"></i>
                <div class="setting-text">
                    <h4>Do Not Disturb</h4>
                    <p>Mute notifications for a specific period of time.</p>
                </div>
                <input class="form-check-input" type="checkbox" id="doNotDisturb" ${settings.notifications.doNotDisturb ? 'checked' : ''}>
            </div>
        </div>
        
        
        <div class="dark-mode">
            <h2>Dark Mode</h2>
            <p>Adjust the appearance of Messenger to reduce glare and give your eyes a break.</p>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="darkMode" id="darkModeOff" ${settings.darkMode === 'off' ? 'checked' : ''}>
                <label class="form-check-label" for="darkModeOff">
                    Off
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="darkMode" id="darkModeOn" ${settings.darkMode === 'on' ? 'checked' : ''}>
                <label class="form-check-label" for="darkModeOn">
                    On
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="darkMode" id="darkModeAutomatic" ${settings.darkMode === 'automatic' ? 'checked' : ''}>
                <label class="form-check-label" for="darkModeAutomatic">
                    Automatic
                </label>
            </div>
        </div>
        <div class="setting-option">
            <i data-feather="credit-card" class="setting-icon"></i>
            <div class="setting-text">
                <h4>Manage payments</h4>
            </div>
        </div>
        
    `;
    feather.replace();
}

// Marketplace
async function populateMarketplace() {
    const marketplaceItems = await fetchData('marketplace');
    const listElement = document.querySelector('#marketplace .marketplace-list');
    listElement.innerHTML = '';
    marketplaceItems.forEach(item => {
        const marketplaceItem = document.createElement('div');
        marketplaceItem.className = 'marketplace-item';
        marketplaceItem.innerHTML = `
            <img src="${item.image || 'https://via.placeholder.com/50'}" alt="${item.title}'s Image">
            <div class="marketplace-details">
                <span class="title">${item.title}</span>
                <span class="seller">${item.seller}</span>
                <span class="time">${item.time}</span>
            </div>
            ${item.unread ? '<div class="unread-indicator"></div>' : ''}
        `;
        listElement.appendChild(marketplaceItem);
    });
    feather.replace();
}

async function populateRequests() {
    const requests = await fetchData('requests');
    const listElement = document.querySelector('#requests .request-list');
    listElement.innerHTML = '';
    requests.forEach(request => {
        const requestItem = document.createElement('div');
        requestItem.className = 'request-item';
        requestItem.innerHTML = `
            <img src="${request.avatar || 'https://via.placeholder.com/50'}" alt="${request.name}'s Avatar">
            <div class="request-details">
                <span class="name">${request.name}</span>
                <span class="message">${request.message}</span>
                <span class="time">${request.time}</span>
            </div>
        `;
        listElement.appendChild(requestItem);
    });
    feather.replace();
}

// Show Specific Section
function showSection(sectionId) {
    const sections = document.querySelectorAll('.section');
    const chatWindow = document.querySelector('.chat-window');
    sections.forEach(section => section.classList.remove('active'));
    sections.forEach(section => section.classList.add('hidden'));
    document.getElementById(sectionId).classList.remove('hidden');
    document.getElementById(sectionId).classList.add('active');
    
    
    if (sectionId === 'chats') {
        populateContacts();
    } else if (sectionId === 'archived') {
        showCallHistory();
    } else if (sectionId === 'settings') {
        populateSettings();
    } else if (sectionId === 'marketplace'){
        populateMarketplace();
    } else if (sectionId === 'requests'){
        populateRequests();
    }
    
}

// Setup Sidebar Navigation
function setupSidebar() {
    const sidebarItems = document.querySelectorAll('.sidebar li');
    sidebarItems.forEach(item => {
        item.addEventListener('click', () => {
            sidebarItems.forEach(i => i.classList.remove('active'));
            
            const sectionId = item.dataset.section;
            showSection(sectionId);
            item.classList.add('active');
        });
    });
}

function closeChatWindow(){
    const chatWindow = document.querySelector('.chat-window');
    chatWindow.style.display = 'none';
}

function closeSettings(){
    showSection('chats');
}

// Setup Search
function setupSearch() {
    const searchInput = document.getElementById('search');
    searchInput.addEventListener('input', async () => {
        const searchTerm = searchInput.value.toLowerCase();
        
        const response = await fetch(`${apiUrl}/search?term=${searchTerm}`);
        
        if (!response.ok) {
            console.error('Failed to fetch search results');
            return;
        }

        const searchData = await response.json();

        
        const listElement = document.querySelector('#chats .chat-list');
        listElement.innerHTML = '';

        
        if (searchData.contacts && searchData.contacts.length > 0) {
            searchData.contacts.forEach(contact => {
                const contactItem = document.createElement('div');
                const lastMessage = contact.lastMessage || { text: "", time: "" };
                contactItem.className = 'chat-item';
                contactItem.innerHTML = `
                    <img src="${contact.avatar || 'https://via.placeholder.com/50'}" alt="${contact.name}'s Avatar">
                    <div class="chat-details">
                        <span class="name">${contact.name}</span>
                        <span class="preview">${lastMessage.text}</span>
                    </div>
                    <span class="time">${lastMessage.time}</span>
                    ${contact.unread ? '<div class="unread-indicator"></div>' : ''}
                `;
                contactItem.addEventListener('click', () => showMessages(contact.name));
                listElement.appendChild(contactItem);
            });
        } else if (searchData.messages && searchData.messages.length > 0) {
            
            searchData.messages.forEach(message => {
                const messageItem = document.createElement('div');
                messageItem.className = 'search-message-item';
                messageItem.innerHTML = `
                    <img src="${message.avatar || 'https://via.placeholder.com/50'}" alt="Avatar">
                    <div class="message-details">
                        <span class="sender">${message.sender}</span>
                        <span class="content">${message.text}</span>
                    </div>
                    <span class="time">${message.time}</span>
                `;
                listElement.appendChild(messageItem);
            });
        } else {
            
            listElement.innerHTML = '<div class="no-results">No results found</div>';
        }

        
        feather.replace();
    });
}

// Initialize Application
async function initializeApp() {
    setupSidebar();
    setupSearch();
    await populateContacts();
    const profileIcon = document.getElementById('profile-icon');
    const settings = await fetchData('settings');
    profileIcon.src = settings.account.avatar || 'https://via.placeholder.com/50';
}

// Start the app
document.addEventListener('DOMContentLoaded', initializeApp);