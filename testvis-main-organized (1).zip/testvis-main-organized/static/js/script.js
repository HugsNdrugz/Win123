
const apiUrl = "http://localhost:5000"; // Base API URL for backend

// Static Data Containers
let chatsData = [];
let requestsData = [];

// DOM Elements
const chatList = document.querySelector('#chats .chat-list');
const requestList = document.querySelector('#requests .request-list');
const sidebarItems = document.querySelectorAll('.sidebar li');

// Helper Function: Fetch Data
async function fetchData(endpoint) {
    try {
        const response = await fetch(`${apiUrl}/${endpoint}`);
        if (!response.ok) throw new Error('Failed to fetch data');
        return await response.json();
    } catch (error) {
        console.error(error);
        return [];
    }
}

// Populate Chats
async function loadChats() {
    chatsData = await fetchData('contacts');
    chatList.innerHTML = chatsData.map(chat => `<div>${chat.name}</div>`).join('');
}

// Populate Requests
async function loadRequests() {
    requestsData = await fetchData('requests');
    requestList.innerHTML = requestsData.map(request => `<div>${request.title}</div>`).join('');
}

// Sidebar Navigation
sidebarItems.forEach(item => {
    item.addEventListener('click', () => {
        const section = document.querySelector(`#${item.dataset.section}`);
        document.querySelectorAll('.section').forEach(sec => sec.classList.add('hidden'));
        section.classList.remove('hidden');
    });
});

// Initial Load
loadChats();
loadRequests();
